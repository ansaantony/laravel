<body background="images/g1.jpg">
@extends('layouts.add')
@section('contents')

<h1><marquee>Welcome</marquee></h1>
<h3><?php echo $titles; ?><br></h3>
 {{$titles}}
@endsection