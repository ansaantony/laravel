<?php $__env->startSection('contents'); ?>
<h1>Haaai Ansa Antony</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>